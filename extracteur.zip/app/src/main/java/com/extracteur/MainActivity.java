package com.extracteur;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private TextView log;
    private ScrollView scroll;
    private Button btn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF121212);
        root.setPadding(p, p * 2, p, p);

        btn = new Button(this);
        btn.setText("Choisir des fichiers");
        btn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "audio/*"});
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(i, 1);
        });
        root.addView(btn, new LinearLayout.LayoutParams(-1, -2));

        scroll = new ScrollView(this);
        log = new TextView(this);
        log.setTextColor(0xFFDDDDDD);
        log.setTextSize(13);
        log.setGravity(Gravity.TOP);
        log.setPadding(0, p, 0, 0);
        log.setText("Sortie : Téléchargements/Extracteur/<nom du fichier>/\n");
        scroll.addView(log);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req != 1 || res != RESULT_OK || data == null) return;
        final List<Uri> uris = new ArrayList<>();
        ClipData cd = data.getClipData();
        if (cd != null) {
            for (int i = 0; i < cd.getItemCount(); i++) uris.add(cd.getItemAt(i).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        btn.setEnabled(false);
        new Thread(() -> {
            for (Uri u : uris) {
                try { process(u); } catch (Exception e) { say("ERREUR : " + e); }
            }
            say("\nTerminé.");
            runOnUiThread(() -> btn.setEnabled(true));
        }).start();
    }

    private void say(final String s) {
        runOnUiThread(() -> {
            log.append(s + "\n");
            scroll.post(() -> scroll.fullScroll(ScrollView.FOCUS_DOWN));
        });
    }

    private String nameOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) { }
        return "media";
    }

    private void process(Uri uri) throws Exception {
        String name = nameOf(uri);
        String base = name.contains(".") ? name.substring(0, name.lastIndexOf('.')) : name;
        base = base.replaceAll("[\\\\/:*?\"<>|]", "_");
        say("\n" + name);
        int n;
        try (ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r")) {
            MediaExtractor ex = new MediaExtractor();
            ex.setDataSource(pfd.getFileDescriptor());
            n = ex.getTrackCount();
            ex.release();
        }
        for (int t = 0; t < n; t++) {
            try { extract(uri, t, base); } catch (Exception e) { say("  " + t + " ERR " + e); }
        }
    }

    private void extract(Uri uri, int t, String base) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        ParcelFileDescriptor in = getContentResolver().openFileDescriptor(uri, "r");
        Uri out = null;
        try {
            ex.setDataSource(in.getFileDescriptor());
            MediaFormat f = ex.getTrackFormat(t);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime == null) return;

            String ext = null, outMime = null, type;
            int fmt = -1;
            boolean raw = false;
            boolean video = mime.startsWith("video/");
            type = video ? "video" : mime.startsWith("audio/") ? "audio" : "autre";

            switch (mime) {
                case "video/avc": case "video/hevc": case "video/av01":
                case "video/mp4v-es": case "video/3gpp":
                    ext = "mp4"; outMime = "video/mp4"; fmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4; break;
                case "video/x-vnd.on2.vp8": case "video/x-vnd.on2.vp9":
                    ext = "webm"; outMime = "video/webm"; fmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM; break;
                case "audio/mp4a-latm":
                    ext = "m4a"; outMime = "audio/mp4"; fmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4; break;
                case "audio/opus":
                    ext = "opus"; outMime = "audio/ogg"; fmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG; break;
                case "audio/vorbis":
                    ext = "webm"; outMime = "audio/webm"; fmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM; break;
                case "audio/mpeg":
                    ext = "mp3"; outMime = "audio/mpeg"; raw = true; break;
                case "audio/ac3":
                    ext = "ac3"; outMime = "audio/ac3"; raw = true; break;
                case "audio/eac3":
                    ext = "eac3"; outMime = "audio/eac3"; raw = true; break;
                default:
                    say("  " + t + " ignoré (" + mime + ")");
                    return;
            }

            String lang = f.containsKey(MediaFormat.KEY_LANGUAGE) ? f.getString(MediaFormat.KEY_LANGUAGE) : "und";
            String fn = String.format("%02d_%s_%s.%s", t, type, lang, ext);

            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fn);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, outMime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Extracteur/" + base);
            out = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (out == null) throw new Exception("création du fichier impossible");

            ex.selectTrack(t);
            ByteBuffer buf = ByteBuffer.allocate(8 << 20);
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();

            if (raw) {
                try (OutputStream os = getContentResolver().openOutputStream(out)) {
                    int sz;
                    while ((sz = ex.readSampleData(buf, 0)) >= 0) {
                        os.write(buf.array(), 0, sz);
                        ex.advance();
                    }
                }
            } else {
                try (ParcelFileDescriptor op = getContentResolver().openFileDescriptor(out, "rw")) {
                    MediaMuxer m = new MediaMuxer(op.getFileDescriptor(), fmt);
                    if (video && f.containsKey("rotation-degrees")) m.setOrientationHint(f.getInteger("rotation-degrees"));
                    int mt = m.addTrack(f);
                    m.start();
                    int sz;
                    while ((sz = ex.readSampleData(buf, 0)) >= 0) {
                        bi.offset = 0;
                        bi.size = sz;
                        bi.presentationTimeUs = ex.getSampleTime();
                        bi.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                        m.writeSampleData(mt, buf, bi);
                        ex.advance();
                    }
                    m.stop();
                    m.release();
                }
            }
            say("  OK  " + fn);
            out = null;
        } catch (Exception e) {
            if (out != null) { try { getContentResolver().delete(out, null, null); } catch (Exception ignored) { } }
            throw e;
        } finally {
            ex.release();
            in.close();
        }
    }
}
